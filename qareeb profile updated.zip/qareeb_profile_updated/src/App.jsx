import React, { useEffect, useRef, useState } from 'react';
import {
  Search,
  Layers,
  ShieldCheck,
  Fingerprint,
  Star,
  Flag,
  History,
  UserCheck,
  Calendar,
  UtensilsCrossed,
  Wrench,
  Car,
  Store,
  PartyPopper,
  Eye,
  Target,
  ArrowLeft,
  CheckCircle,
  Mail,
  Phone,
  MessageCircle,
  Puzzle,
} from 'lucide-react';
import logoHorizontal from './assets/qareeb-logo-horizontal.png';
import logoPrimary from './assets/qareeb-logo-primary.png';
import './index.css';

/* ── Scroll Reveal Hook ── */
function useScrollReveal() {
  useEffect(() => {
    const els = document.querySelectorAll(
      '.reveal, .reveal-right, .reveal-left, .reveal-scale'
    );

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -60px 0px' }
    );

    els.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
}

/* ── Main App ── */
function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);

  useScrollReveal();

  /* Sticky header + scroll-to-top visibility */
  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 40);
      setShowScrollTop(window.scrollY > 400);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  /* Lock body scroll when mobile menu open */
  useEffect(() => {
    document.body.style.overflow = menuOpen ? 'hidden' : '';
  }, [menuOpen]);

  const closeMenu = () => setMenuOpen(false);

  const navItems = [
    { href: '#home', label: 'الرئيسية' },
    { href: '#how-it-works', label: 'إزاي بيشتغل' },
    { href: '#workflows', label: 'الفئات' },
    { href: '#trust', label: 'الثقة' },
    { href: '#vision', label: 'رؤيتنا' },
    { href: '#contact', label: 'تواصل معنا' },
  ];

  const workflows = [
    { icon: <Calendar size={36} />, title: 'مواعيد', example: 'دكاترة وعيادات', desc: 'احجز موعدك، اختار الوقت المناسب، واستلم تذكير قبل الزيارة.' },
    { icon: <UtensilsCrossed size={36} />, title: 'أوردرات', example: 'مطاعم', desc: 'اطلب من المنيو، تابع حالة الأوردر لحظة بلحظة لحد ما يوصلك.' },
    { icon: <Wrench size={36} />, title: 'طلب خدمة', example: 'كهربائيين وسباكين', desc: 'وصف احتياجك، استلم عرض سعر أو اتربط بأقرب شريك متاح.' },
    { icon: <Car size={36} />, title: 'طلب مفتوح', example: 'مواصلات وتوصيل', desc: 'حدد نقطة الانطلاق والوجهة، وتابع رحلتك لحظة بلحظة.' },
    { icon: <Store size={36} />, title: 'بيع وشراء', example: 'سوق مفتوح', desc: 'اعرض غرضك أو دور على اللي محتاجه من ناس حواليك.' },
    { icon: <PartyPopper size={36} />, title: 'حجوزات', example: 'قاعات ومناسبات', desc: 'شوف التوفر والباقات، واحجز مكانك للمناسبة بثقة.' },
  ];

  const trustPillars = [
    { icon: <Fingerprint size={32} />, title: 'توثيق الشركاء', desc: 'كل شريك بيتوثق قبل ما يبقى ظاهر على المنصة' },
    { icon: <Star size={32} />, title: 'تقييمات ومراجعات', desc: 'رأي حقيقي من ناس جربت فعلاً' },
    { icon: <UserCheck size={32} />, title: 'مراجعة يدوية', desc: 'مش مجرد ادعاء — في مراجعة بشرية فعلية' },
    { icon: <Flag size={32} />, title: 'نظام بلاغات', desc: 'أي مشكلة، في طريقة واضحة تبلّغ بيها' },
    { icon: <History size={32} />, title: 'سجل دائم', desc: 'سجل الشريك بيتراكم عبر الوقت، مش بيتصفر كل مرة' },
  ];

  const uvpPoints = [
    { icon: <Fingerprint size={28} />, title: 'حساب واحد، في كل مكان', desc: 'هوية وبروفايل واحد يشتغل مع كل الفئات' },
    { icon: <Search size={28} />, title: 'بحث واحد، لكل احتياج', desc: 'تجربة اكتشاف واحدة بدل ما تتعلم واجهة جديدة كل مرة' },
    { icon: <ShieldCheck size={28} />, title: 'طبقة ثقة واحدة', desc: 'التقييم والتوثيق والسجل بيتبعوا الشريك في كل المنصة' },
    { icon: <Layers size={28} />, title: 'تجربة متسقة', desc: 'كل فئة ليها طريقتها، لكن الإحساس العام واحد' },
  ];

  return (
    <>
      {/* ── Scroll to Top ── */}
      <button
        className={`scroll-top ${showScrollTop ? 'visible' : ''}`}
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        aria-label="العودة للأعلى"
      >
        <ArrowLeft size={20} style={{ transform: 'rotate(90deg)' }} />
      </button>

      {/* ── Mobile Menu Overlay ── */}
      <div
        className={`mobile-menu-overlay ${menuOpen ? 'active' : ''}`}
        onClick={closeMenu}
        aria-hidden="true"
      />

      {/* ── Mobile Nav ── */}
      <nav className={`mobile-nav ${menuOpen ? 'active' : ''}`} aria-label="القائمة الرئيسية">
        <ul>
          {navItems.map(({ href, label }) => (
            <li key={href}>
              <a href={href} onClick={closeMenu}>{label}</a>
            </li>
          ))}
        </ul>
      </nav>

      {/* ── Header ── */}
      <header className={`header ${scrolled ? 'scrolled' : ''}`}>
        <div className="container">
          <a href="#home" className="logo" aria-label="قريب Qareeb">
            <img src={logoHorizontal} alt="قريب Qareeb" style={{ height: '36px', width: 'auto' }} />
          </a>

          <nav aria-label="التنقل الرئيسي">
            <ul className="nav-links">
              {navItems.map(({ href, label }) => (
                <li key={href}>
                  <a href={href}>{label}</a>
                </li>
              ))}
            </ul>
          </nav>

          <button
            className={`menu-toggle ${menuOpen ? 'active' : ''}`}
            onClick={() => setMenuOpen((v) => !v)}
            aria-label={menuOpen ? 'إغلاق القائمة' : 'فتح القائمة'}
            aria-expanded={menuOpen}
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </header>

      {/* ── Hero ── */}
      <section id="home" className="hero">
        <div className="hero-shape hero-shape-1" aria-hidden="true" />
        <div className="hero-shape hero-shape-2" aria-hidden="true" />
        <div className="hero-shape hero-shape-3" aria-hidden="true" />
        <div className="hero-dots" aria-hidden="true" />

        <div className="container hero-container">
          <div className="hero-content">
            <span className="subtitle">منصة محلية موحدة</span>
            <h1>
              كل احتياج محلي، <span>في مكان واحد</span>
            </h1>
            <p>
              قريب منصة محلية موحدة بتجمع خدمات وأعمال ومنتجات ومعاملات محلية
              متعددة في تجربة واحدة متسقة — بدل ما تدور بين تطبيقات متفرقة
              لكل احتياج، حساب واحد وثقة واحدة تكفيك لكل حاجة في منطقتك.
            </p>
            <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
              <a href="#contact" className="btn btn-primary">
                انضم كشريك مبكر
                <ArrowLeft size={20} />
              </a>
              <a href="#workflows" className="btn btn-secondary">
                استكشف الفئات
              </a>
            </div>
          </div>

          <div className="hero-image-wrapper">
            <img
              src={logoPrimary}
              alt="قريب Qareeb"
              loading="eager"
              style={{ maxWidth: '380px', margin: '0 auto' }}
            />
            <div className="hero-badge">
              <div className="hero-badge-dot" />
              المنصة بتتكيف مع الخدمة
            </div>
          </div>
        </div>
      </section>

      {/* ── How It Works ── */}
      <section id="how-it-works" className="stats">
        <div className="container">
          <h2 className="section-title reveal" style={{ color: 'white' }}>إزاي قريب بيشتغل</h2>
          <p className="section-subtitle reveal" style={{ color: 'rgba(255,255,255,0.75)' }}>
            المستخدم بيبدأ من احتياجه، والمنصة بتوجهه للـ Workflow المناسب — من غير ما نفترض طريقة معينة
          </p>
          <div className="stats-grid stagger-children">
            {[
              { n: '٠١', title: 'حدد احتياجك', desc: 'فئة، شريك معين، أو احتياج عام' },
              { n: '٠٢', title: 'قريب بيوجهك', desc: 'للفئة الصح والـ Workflow الخاص بيها' },
              { n: '٠٣', title: 'أنجز المعاملة', desc: 'حجز، أوردر، طلب، أو شراء — حسب الفئة' },
              { n: '٠٤', title: 'ثق وقيّم', desc: 'التوثيق والتقييمات ظاهرة طول الوقت' },
            ].map(({ n, title, desc }) => (
              <div className="stat-item reveal" key={n}>
                <div className="stat-icon" style={{ fontSize: '1.1rem', fontWeight: 700 }}>{n}</div>
                <span className="stat-number" style={{ fontSize: '1.15rem' }}>{title}</span>
                <span className="stat-label">{desc}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Problem (Fragmentation) ── */}
      <section id="about" className="about">
        <div className="container">
          <div className="about-grid">
            <div className="about-image-side reveal-left">
              <div
                className="about-image-main"
                style={{
                  background: 'linear-gradient(135deg, var(--color-secondary), var(--color-secondary-light))',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  minHeight: '340px',
                  padding: '2rem',
                }}
              >
                <img src={logoPrimary} alt="قريب" style={{ maxWidth: '220px', filter: 'brightness(0) invert(1)', opacity: 0.9 }} />
              </div>
              <div className="about-image-badge">
                <strong>٣</strong>
                <span>مستويات تشتت بنحلها</span>
              </div>
            </div>

            <div className="about-content reveal-right">
              <h2 className="section-title">المشكلة اللي قريب بيحلها</h2>
              <p style={{ color: 'var(--color-text-muted)', marginBottom: '1.5rem', lineHeight: 1.8 }}>
                المشكلة الحقيقية مش إن الناس مش لاقية اللي محتاجاه — المشكلة هي
                <strong style={{ color: 'var(--color-primary)' }}> التشتت</strong>.
              </p>
              <ul className="about-points">
                {[
                  {
                    icon: <Puzzle size={22} />,
                    title: 'تشتت الأدوات',
                    desc: 'تطبيق مختلف لكل احتياج: دكتور، مطعم، مواصلات، صيانة، بيع وشراء.',
                  },
                  {
                    icon: <ShieldCheck size={22} />,
                    title: 'تشتت الثقة',
                    desc: 'من غير نظام توثيق موحد، الثقة لازم تتبني من الصفر مع كل حد.',
                  },
                  {
                    icon: <Layers size={22} />,
                    title: 'تشتت التجربة',
                    desc: 'كل أداة بواجهتها وحسابها الخاص — تتعلم من الأول كل مرة.',
                  },
                ].map(({ icon, title, desc }) => (
                  <li className="about-point" key={title}>
                    <div className="about-point-icon">{icon}</div>
                    <div className="about-point-text">
                      <strong>{title}</strong>
                      <span>{desc}</span>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* ── Workflows / Categories ── */}
      <section id="workflows" className="section features">
        <div className="container">
          <h2 className="section-title reveal">فئة واحدة، طريقتها الخاصة</h2>
          <p className="section-subtitle reveal">
            المنصة بتتكيف مع الخدمة، مش العكس — كل فئة ليها الـ Workflow اللي يناسبها، على حساب وثقة وتجربة واحدة
          </p>

          <div className="features-grid stagger-children">
            {workflows.map(({ icon, title, example, desc }, i) => (
              <div className="feature-card reveal" key={title}>
                <span className="feature-card-num">{String(i + 1).padStart(2, '0')}</span>
                <div className="feature-icon">{icon}</div>
                <h3>{title}</h3>
                <p style={{ color: 'var(--color-primary)', fontWeight: 600, fontSize: '0.85rem', marginBottom: '0.4rem' }}>{example}</p>
                <p>{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Why Qareeb (UVP) ── */}
      <section id="why" className="section values">
        <div className="container">
          <h2 className="section-title reveal">ليه قريب؟</h2>
          <p className="section-subtitle reveal">
            ليه تستخدم قريب بدل ما تفتح خمس تطبيقات منفصلة
          </p>

          <div className="values-grid stagger-children">
            {uvpPoints.map(({ icon, title, desc }) => (
              <div className="value-item reveal" key={title}>
                <div className="value-icon">{icon}</div>
                <h4>{title}</h4>
                <p>{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Trust & Safety ── */}
      <section id="trust" className="section values" style={{ background: 'var(--color-bg)' }}>
        <div className="container">
          <h2 className="section-title reveal">الثقة هي الأساس</h2>
          <p className="section-subtitle reveal">
            الثقة هي اللي بتخلي قريب أفضل من التوصية الشخصية أو جروبات السوشيال ميديا
          </p>

          <div className="values-grid stagger-children">
            {trustPillars.map(({ icon, title, desc }) => (
              <div className="value-item reveal" key={title}>
                <div className="value-icon">{icon}</div>
                <h4>{title}</h4>
                <p>{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Vision & Mission ── */}
      <section id="vision" className="section vision-mission">
        <div className="container">
          <h2 className="section-title reveal">رؤيتنا ورسالتنا</h2>
          <p className="section-subtitle reveal">
            نؤمن إن الاحتياجات المحلية تستاهل تجربة أبسط وأوثق
          </p>

          <div className="vm-grid">
            <div className="vm-card reveal-left">
              <Eye size={100} className="vm-icon" strokeWidth={1} />
              <h3>رؤيتنا</h3>
              <p>
                إن نبقى المنصة المحلية الأساسية اللي الناس تقدر من خلالها
                تكتشف وتوصل وتطلب وتحجز وتبيع وتشتري أي حاجة محتاجينها في
                مجتمعهم، من خلال تطبيق واحد موثوق.
              </p>
              <div style={{ marginTop: '1.5rem', display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                {['Operating Platform للمجتمعات المحلية', 'أي فئة جديدة من غير إعادة بناء', 'تجربة واحدة موثوقة للجميع'].map((item) => (
                  <div key={item} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--color-primary)' }}>
                    <CheckCircle size={18} />
                    <span style={{ fontSize: '0.95rem', color: 'var(--color-text)' }}>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="vm-card reveal-right">
              <Target size={100} className="vm-icon" strokeWidth={1} />
              <h3>رسالتنا</h3>
              <p>
                نخلي الاحتياجات المحلية متاحة من خلال منصة واحدة بسيطة
                وموثوقة وقابلة للتوسع — للأفراد والشركات على حد سواء.
              </p>
              <div style={{ marginTop: '1.5rem', display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                {['المنصة بتتكيف مع الخدمة، مش العكس', 'وصول مجاني لطالبي الخدمة دايماً', 'باقات اشتراك عادلة للشركاء'].map((item) => (
                  <div key={item} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--color-primary)' }}>
                    <CheckCircle size={18} />
                    <span style={{ fontSize: '0.95rem', color: 'var(--color-text)' }}>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section id="contact" className="cta">
        <div className="container">
          <h2 className="reveal">عايز تكون من أول الشركاء في قريب؟</h2>
          <p className="reveal">تواصل معنا مباشرة عبر البريد أو الهاتف أو الواتساب</p>
          <div className="reveal" style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap', marginTop: '1.5rem' }}>
            <a href="https://wa.me/201067156319" target="_blank" rel="noopener noreferrer" className="btn btn-white">
              <MessageCircle size={20} color="var(--color-primary)" />
              واتساب: 01067156319
            </a>
            <a href="tel:01067156319" className="btn btn-white">
              <Phone size={20} color="var(--color-primary)" />
              اتصال: 01067156319
            </a>
            <a href="mailto:mn877007@gmail.com" className="btn btn-white">
              <Mail size={20} color="var(--color-primary)" />
              mn877007@gmail.com
            </a>
          </div>
        </div>
      </section>

      {/* ── Footer ── */}
      <footer className="footer">
        <div className="container">
          <div className="footer-content">
            <a href="#home" className="logo" style={{ color: 'white' }}>
              <img src={logoHorizontal} alt="قريب" style={{ height: '32px', width: 'auto', filter: 'brightness(0) invert(1)' }} />
            </a>

            <p className="footer-tagline">
              منصة محلية موحدة بتربطك بكل خدمة وعمل ومنتج في مجتمعك، من خلال
              تجربة واحدة موثوقة.
            </p>

            <div className="social-links" style={{ gap: '1rem', flexWrap: 'wrap', justifyContent: 'center' }}>
              <a href="https://wa.me/201067156319" target="_blank" rel="noopener noreferrer">
                <MessageCircle size={18} style={{ marginLeft: '6px' }} />
                واتساب: 01067156319
              </a>
              <a href="tel:01067156319">
                <Phone size={18} style={{ marginLeft: '6px' }} />
                هاتف: 01067156319
              </a>
              <a href="mailto:mn877007@gmail.com">
                <Mail size={18} style={{ marginLeft: '6px' }} />
                mn877007@gmail.com
              </a>
            </div>
          </div>

          <div className="footer-bottom">
            &copy; {new Date().getFullYear()} قريب. جميع الحقوق محفوظة.
          </div>
        </div>
      </footer>
    </>
  );
}

export default App;
